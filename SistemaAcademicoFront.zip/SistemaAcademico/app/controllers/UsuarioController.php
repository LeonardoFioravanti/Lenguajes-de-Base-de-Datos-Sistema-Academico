class UsuariosController {
    public function index() {
        require 'app/views/usuarios.php';
    }
}
