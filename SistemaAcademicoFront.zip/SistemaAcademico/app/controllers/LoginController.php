<?php

// Logica temporal sin base de datos
if (isset($_POST['usuario']) && isset($_POST['password'])) {
    header("Location: ../views/panel.php");
    exit();
} else {
    echo "Datos incompletos";
}
?>
